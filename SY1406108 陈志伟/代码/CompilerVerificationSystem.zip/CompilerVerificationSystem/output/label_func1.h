
#include <stdio.h>                                // 10

int add(int x, int y);                            // 11
