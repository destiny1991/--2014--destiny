
#include <stdio.h>                                // 16

int sub(int x, int y, int d);                     // 17
