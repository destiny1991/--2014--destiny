//
// Created by destiny on 16/9/5.
//

#include <stdio.h>

int add(int x, int y);
