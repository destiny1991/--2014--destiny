//
// Created by destiny on 16/9/5.
//

#include <stdio.h>

int sub(int x, int y, int d);
