#include <stdio.h>
#include "func2.h"

//
// Created by destiny on 16/9/5.
//
//
//
//
//

int sub(int x, int y, int d) {
    int z;
    z = x - y - d;
    printf("sub function %d\n", z);
    return z;
}