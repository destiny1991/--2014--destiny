package cn.edu.buaa.constant;

import java.util.Arrays;
import java.util.List;

public class ProverDefine {
	
	public static final List<String> LOOPS = Arrays.asList("do_while", "while", "for");
	public static final String TAB = "\t\t";
}
