package cn.edu.buaa.templates;

/**
 * Hello world!
 *
 */
public class App {
	
	public int add(int x, int y) {
		return x + y;
	}
	
	public static void main(String[] args) {
		
		
		
		String string = "\n";
		System.out.println(string.charAt(1));
		
		
	}
	
}
